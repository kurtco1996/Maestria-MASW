export class Cancion{
    constructor(
        public pista: number,
        public titulo: string,
        public artista: string,
        public ruta: string
    ){
        
    }
}